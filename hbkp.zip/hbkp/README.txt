
    Hello! 

    This is a program that is designed to give you infinite time on your computer, do be aware however, that you will need administrator to use it.
    If you do not have administrator, you will not be able to use this program unfortunately.

    However, if you do have administrator, please run the batch file named "install.bat" to setup the program!